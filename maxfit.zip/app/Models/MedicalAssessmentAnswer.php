<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalAssessmentAnswer extends Model
{
    protected $guarded = [];
}
