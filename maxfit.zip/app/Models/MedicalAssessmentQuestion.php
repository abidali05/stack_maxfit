<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MedicalAssessmentQuestion extends Model
{
    protected $guarded = [];
}
