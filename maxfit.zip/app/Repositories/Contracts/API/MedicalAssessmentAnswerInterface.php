<?php

namespace App\Repositories\Contracts\API;

interface MedicalAssessmentAnswerInterface {
    public function store_medical_assessment_answers(array $data);
}
