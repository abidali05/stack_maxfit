<?php

namespace App\Repositories\Contracts;

interface ResultRepositoryInterface
{
    public function get_results();
}
