<?php

namespace App\Repositories\Contracts;

interface PlanAnswerRepositoryInterface
{
    public function store_plan_answers(array $data);
}
