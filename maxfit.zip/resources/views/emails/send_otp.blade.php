<p>Your OTP for password reset is: <strong>{{ $otp }}</strong></p>
<p>This OTP will expire in 10 minutes.</p>
